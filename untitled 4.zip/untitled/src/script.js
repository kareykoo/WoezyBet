// Символы и их вероятности
const fruits = ['🍒', '🍋', '🍊', '🍇', '🍉', '🍑', '🃏', '🔔']; // Все символы
const symbolChances = {
  '🍒': 0.30,
  '🍋': 0.25,
  '🍊': 0.20,
  '🍇': 0.10,
  '🍉': 0.07,
  '🍑': 0.05,
  '🃏': 0.02,
  '🔔': 0.01,
};

// Инициализация
let balance = 1000;
let topWinners = [];
const betAmountInput = document.getElementById('bet-amount');
const spinButton = document.getElementById('spin-button');
const winMessage = document.getElementById('win-message');
const balanceElement = document.getElementById('balance');
const topWinnersList = document.getElementById('top-winners');
const redButton = document.getElementById('red-button');
const blackButton = document.getElementById('black-button');

// Функция для случайного выбора символа
function getRandomFruit() {
  const rand = Math.random();
  let cumulativeChance = 0;

  for (const symbol in symbolChances) {
    cumulativeChance += symbolChances[symbol];
    if (rand < cumulativeChance) {
      return symbol;
    }
  }
  return fruits[fruits.length - 1];
}

// Функция для проверки линии
function isWinningLine(line) {
  return line.every(symbol => symbol === line[0]);
}

// Функция для расчета выигрыша в зависимости от символа
function calculateWin(symbol) {
  switch (symbol) {
    case '🍒':
      return betAmountInput.value * 2;
    case '🍋':
      return betAmountInput.value * 3;
    case '🍊':
      return betAmountInput.value * 4;
    case '🍇':
      return betAmountInput.value * 5;
    case '🍉':
      return betAmountInput.value * 6;
    case '🍑':
      return betAmountInput.value * 7;
    case '🃏':
      return betAmountInput.value * 10;
    case '🔔':
      return betAmountInput.value * 50;
    default:
      return 0;
  }
}

// Функция для начала вращения
function spin() {
  const columns = document.querySelectorAll('.column');
  const slotValues = [];

  // Анимация вращения
  columns.forEach((column) => {
    const slots = column.querySelectorAll('.slot');
    const columnValues = Array.from(slots).map(slot => getRandomFruit());
    slotValues.push(columnValues);

    column.classList.add('spinning');
  });

  setTimeout(() => {
    columns.forEach((column) => column.classList.remove('spinning'));
  }, 1500);

  // Проверка на выигрыш
  let isWin = false;
  let winAmount = 0;

  for (let row = 0; row < 4; row++) {
    const line = slotValues.map(column => column[row]);
    if (isWinningLine(line)) {
      isWin = true;
      winAmount += calculateWin(line[0]);
    }
  }

  // Обновляем слоты с новыми значениями
  columns.forEach((column, colIndex) => {
    const slots = column.querySelectorAll('.slot');
    slots.forEach((slot, rowIndex) => {
      slot.textContent = slotValues[colIndex][rowIndex];
    });
  });

  // Обновляем баланс
  if (isWin) {
    balance += winAmount;
    balanceElement.textContent = balance;
    winMessage.textContent = `Вы выиграли ${winAmount}!`;
    
    // Добавление в топ выигрышей
    topWinners.push(winAmount);
    topWinners.sort((a, b) => b - a); // Сортировка по убыванию

    if (topWinners.length > 5) topWinners = topWinners.slice(0, 5); // Оставляем только 5 лучших

    topWinnersList.innerHTML = '';
    topWinners.forEach(amount => {
      const listItem = document.createElement('li');
      listItem.textContent = `Выигрыш: ${amount}`;
      topWinnersList.appendChild(listItem);
    });
  } else {
    winMessage.textContent = "Вы проиграли.";
  }
}

// Выбор умножителя
function applyMultiplier(color) {
  const multiplier = Math.random() < 0.5 ? 2 : 1;
  const isWin = (color === 'red' && multiplier === 2) || (color === 'black' && multiplier === 1);

  if (isWin) {
    const winAmount = betAmountInput.value * multiplier;
    balance += winAmount;
    balanceElement.textContent = balance;
    winMessage.textContent = `Вы выиграли ${winAmount}!`;
  } else {
    balance -= betAmountInput.value;
    balanceElement.textContent = balance;
    winMessage.textContent = "Вы проиграли!";
  }
}

// События
spinButton.addEventListener('click', () => {
  if (betAmountInput.value <= 0 || betAmountInput.value > balance) {
    alert("Введите корректную ставку.");
  } else {
    spin();
  }
});

redButton.addEventListener('click', () => {
  applyMultiplier('red');
});

blackButton.addEventListener('click', () => {
  applyMultiplier('black');
});